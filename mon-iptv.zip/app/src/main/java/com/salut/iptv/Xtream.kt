package com.salut.iptv

import android.net.Uri
import android.util.JsonReader
import android.util.JsonToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONObject

class Sub(val text: String, val warn: Boolean)

class XCfg(val host: String, val user: String, val pass: String)

object Xtream {
    fun fromUrl(url: String): XCfg? {
        try {
            val uri = Uri.parse(url)
            val u = uri.getQueryParameter("username") ?: return null
            val p = uri.getQueryParameter("password") ?: return null
            if (uri.path?.endsWith("get.php") != true) return null
            val port = if (uri.port != -1) ":${uri.port}" else ""
            return XCfg("${uri.scheme}://${uri.host}$port", u, p)
        } catch (e: Exception) {
            return null
        }
    }

    fun subscription(url: String): Sub? {
        val c = fromUrl(url) ?: return null
        try {
            val conn = openConn("${c.host}/player_api.php?username=${Uri.encode(c.user)}&password=${Uri.encode(c.pass)}")
            conn.readTimeout = 15000
            if (conn.responseCode != 200) return null
            val txt = conn.inputStream.bufferedReader().use { it.readText() }
            val ui = JSONObject(txt).optJSONObject("user_info") ?: return null
            val exp = ui.optString("exp_date", "")
            val maxC = ui.optString("max_connections", "")
            val act = ui.optString("active_cons", "0")
            val cons = if (maxC.isNotBlank() && maxC != "null") "  ·  Écrans : $act/$maxC" else ""
            val e = exp.toLongOrNull()
            if (e == null || e == 0L) return Sub("⏳ Abonnement illimité$cons", false)
            val days = (e - System.currentTimeMillis() / 1000) / 86400
            val date = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(e * 1000))
            return when {
                days < 0 -> Sub("⛔ Abonnement expiré depuis le $date", true)
                days == 0L -> Sub("⚠️ Dernier jour d'abonnement ($date)$cons", true)
                days == 1L -> Sub("⏳ 1 jour restant · jusqu'au $date$cons", true)
                else -> Sub("⏳ $days jours restants · jusqu'au $date$cons", days <= 7)
            }
        } catch (ex: Exception) {
            return null
        }
    }

    fun api(c: XCfg, action: String, extra: String = ""): String =
        "${c.host}/player_api.php?username=${Uri.encode(c.user)}&password=${Uri.encode(c.pass)}&action=$action$extra"

    private fun JsonReader.str(): String =
        if (peek() == JsonToken.NULL) { skipValue(); "" } else nextString()

    // Lit un tableau JSON d'objets plats ; tolère un fichier tronqué.
    private fun readObjects(f: File, onObj: (Map<String, String>) -> Unit) {
        if (!f.exists()) return
        JsonReader(f.reader(Charsets.UTF_8).buffered()).use { r ->
            r.isLenient = true
            try {
                r.beginArray()
                while (r.hasNext()) {
                    val m = HashMap<String, String>()
                    r.beginObject()
                    while (r.hasNext()) {
                        val k = r.nextName()
                        when (r.peek()) {
                            JsonToken.STRING, JsonToken.NUMBER -> m[k] = r.nextString()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    onObj(m)
                }
            } catch (e: Exception) {
                // fichier tronqué : on garde ce qui a été lu
            }
        }
    }

    fun items(c: XCfg, kind: Kind, catFile: File, dataFile: File): List<Item> {
        val cats = HashMap<String, String>()
        readObjects(catFile) { cats[it["category_id"] ?: ""] = it["category_name"] ?: "" }
        val out = ArrayList<Item>()
        readObjects(dataFile) { m ->
            val name = m["name"]
            if (name != null) {
                val group = cats[m["category_id"] ?: ""] ?: ""
                when (kind) {
                    Kind.LIVE -> m["stream_id"]?.let { id ->
                        out += Item(name, "${c.host}/live/${c.user}/${c.pass}/$id.ts", m["stream_icon"] ?: "", group, kind)
                    }
                    Kind.FILM -> m["stream_id"]?.let { id ->
                        val ext = (m["container_extension"] ?: "").ifBlank { "mp4" }
                        out += Item(name, "${c.host}/movie/${c.user}/${c.pass}/$id.$ext", m["stream_icon"] ?: "", group, kind)
                    }
                    Kind.SERIE -> m["series_id"]?.let { id ->
                        out += Item(name, "series:$id", m["cover"] ?: "", group, kind)
                    }
                }
            }
        }
        return out
    }

    private fun readSeason(r: JsonReader, season: String, c: XCfg, s: Entry, out: MutableList<Entry>) {
        r.beginArray()
        while (r.hasNext()) {
            var id = ""; var title = ""; var num = ""; var ext = "mp4"
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "id" -> id = r.str()
                    "title" -> title = r.str()
                    "episode_num" -> num = r.str()
                    "container_extension" -> ext = r.str().ifBlank { "mp4" }
                    else -> r.skipValue()
                }
            }
            r.endObject()
            if (id.isNotBlank()) {
                val label = "S${season.padStart(2, '0')} E${num.padStart(2, '0')}" +
                    if (title.isNotBlank()) " · $title" else ""
                out += Entry(label, s.logo, "Saison $season", Kind.SERIE,
                    listOf("Auto" to "${c.host}/series/${c.user}/${c.pass}/$id.$ext"))
            }
        }
        r.endArray()
    }

    fun episodes(c: XCfg, series: Entry, f: File): List<Entry> {
        val out = ArrayList<Entry>()
        JsonReader(f.reader(Charsets.UTF_8).buffered()).use { r ->
            r.isLenient = true
            try {
                r.beginObject()
                while (r.hasNext()) {
                    if (r.nextName() != "episodes") { r.skipValue(); continue }
                    when (r.peek()) {
                        JsonToken.BEGIN_OBJECT -> {
                            r.beginObject()
                            while (r.hasNext()) { val season = r.nextName(); readSeason(r, season, c, series, out) }
                            r.endObject()
                        }
                        JsonToken.BEGIN_ARRAY -> {
                            r.beginArray()
                            var i = 1
                            while (r.hasNext()) { readSeason(r, "$i", c, series, out); i++ }
                            r.endArray()
                        }
                        else -> r.skipValue()
                    }
                }
            } catch (e: Exception) {
                // réponse tronquée : on garde les épisodes déjà lus
            }
        }
        return out
    }
}
