package com.salut.iptv

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cast = try { CastContext.getSharedInstance(this) } catch (e: Exception) { null }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(cast) }
            }
        }
    }
}

private fun openConn(s: String): HttpURLConnection =
    (URL(s).openConnection() as HttpURLConnection).apply {
        instanceFollowRedirects = false
        setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
        setRequestProperty("Accept", "*/*")
        setRequestProperty("Accept-Encoding", "identity")
        connectTimeout = 30000
        readTimeout = 180000
    }

private fun download(url: String, dest: File, onMb: (Long) -> Unit) {
    var u = url
    var hops = 0
    var c = openConn(u)
    while (c.responseCode in 301..308 && hops < 5) {
        u = URL(URL(u), c.getHeaderField("Location")).toString()
        c.disconnect(); c = openConn(u); hops++
    }
    if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
    var total = 0L
    var lastMb = -1L
    c.inputStream.use { i ->
        dest.outputStream().use { o ->
            val buf = ByteArray(65536)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                total += n
                val mb = total / 1048576
                if (mb != lastMb) { lastMb = mb; onMb(mb) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(cast: CastContext?) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("iptv", 0) }
    val scope = rememberCoroutineScope()
    val cache = remember { File(ctx.filesDir, "playlist.m3u") }
    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var status by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Entry?>(null) }
    var showSettings by remember { mutableStateOf(url.isEmpty()) }

    fun load(refresh: Boolean) {
        scope.launch {
            status = "Chargement…"
            try {
                val parsed = withContext(Dispatchers.IO) {
                    var partial = false
                    if (refresh || !cache.exists()) {
                        var ok = false
                        var best: File? = null
                        var err: Exception? = null
                        for (n in 1..3) {
                            val f = File(cache.path + ".part$n")
                            try {
                                status = if (n == 1) "Téléchargement…" else "Nouvelle tentative $n/3…"
                                download(url, f) { mb -> status = "Téléchargement… $mb Mo (essai $n/3)" }
                                f.renameTo(cache); ok = true; break
                            } catch (e: java.io.IOException) {
                                err = e
                                if (f.length() > (best?.length() ?: 0L)) best = f
                            }
                        }
                        if (!ok) {
                            val bf = best
                            if (bf != null && bf.length() > 512 * 1024) { bf.renameTo(cache); partial = true }
                            else throw (err ?: Exception("Échec du téléchargement"))
                        }
                    }
                    status = "Analyse de la playlist…"
                    val text = cache.readText()
                    Pair(M3u.parse(if (partial) text.substringBeforeLast("\n") else text), partial)
                }
                entries = parsed.first
                status = when {
                    parsed.first.isEmpty() -> "Playlist vide"
                    parsed.second -> "Liste partielle : le serveur a coupé la connexion. Appuie sur ⟳ pour réessayer."
                    else -> ""
                }
            } catch (e: Exception) {
                status = "Erreur : ${e.message}"
            }
        }
    }
    LaunchedEffect(Unit) { if (url.isNotEmpty()) load(false) }

    fun toggle(k: String) {
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("favs", favs).apply()
    }

    val kinds = listOf(Kind.LIVE, Kind.FILM, Kind.SERIE)
    val base = remember(entries, tab, favs) {
        if (tab == 3) entries.filter { it.key in favs } else entries.filter { it.kind == kinds[tab] }
    }
    val groups = remember(base) { base.map { it.group }.filter { it.isNotBlank() }.distinct() }
    val shown = remember(base, group, query) {
        base.filter { (group == null || it.group == group) && it.base.contains(query, true) }
    }

    val current = playing
    if (current != null) {
        PlayerScreen(current, cast) { playing = null }
        return
    }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("📺 Live TV", "🎬 Films", "📚 Séries", "⭐ Favoris").forEachIndexed { i, t ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i; group = null },
                    icon = { Text(t.substringBefore(" ")) },
                    label = { Text(t.substringAfter(" ")) },
                )
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Rechercher") }, singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { load(true) }) { Text("⟳") }
                TextButton(onClick = { showSettings = true }) { Text("⚙") }
            }
            if (status.isNotEmpty()) Text(status, Modifier.padding(8.dp))
            if (groups.isNotEmpty()) {
                LazyRow(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { FilterChip(group == null, { group = null }, { Text("Tous") }) }
                    items(groups) { g -> FilterChip(group == g, { group = g }, { Text(g) }) }
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown) { e ->
                    Row(
                        Modifier.fillMaxWidth().clickable { playing = e }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AsyncImage(e.logo, null, Modifier.size(44.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.base, maxLines = 1)
                            Text(
                                e.variants.joinToString(" · ") { it.first } +
                                    if (e.group.isNotBlank()) "  —  ${e.group}" else "",
                                style = MaterialTheme.typography.bodySmall, maxLines = 1,
                            )
                        }
                        TextButton(onClick = { toggle(e.key) }) { Text(if (e.key in favs) "★" else "☆") }
                    }
                }
            }
        }
    }

    if (showSettings) {
        var tmp by remember { mutableStateOf(url) }
        AlertDialog(
            onDismissRequest = { if (url.isNotEmpty()) showSettings = false },
            title = { Text("URL de la playlist M3U") },
            text = { OutlinedTextField(tmp, { tmp = it }) },
            confirmButton = {
                TextButton(onClick = {
                    url = tmp.trim()
                    prefs.edit().putString("url", url).apply()
                    showSettings = false
                    load(true)
                }) { Text("Charger") }
            },
        )
    }
}

private fun mime(u: String): String? = when {
    ".m3u8" in u -> "application/x-mpegURL"
    u.endsWith(".mp4") -> "video/mp4"
    u.endsWith(".mkv") -> "video/x-matroska"
    u.endsWith(".ts") -> "video/mp2t"
    else -> null
}

// Le Chromecast lit mal les .ts bruts : on tente le HLS pour les chaînes live.
private fun castUrl(u: String) =
    if ("/live/" in u && u.endsWith(".ts")) u.dropLast(3) + ".m3u8" else u

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(entry: Entry, cast: CastContext?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    val castPlayer = remember { cast?.let { CastPlayer(it) } }
    var active by remember { mutableStateOf<Player>(exo) }
    var selected by remember { mutableStateOf(0) }

    fun play(p: Player, idx: Int, pos: Long) {
        val raw = entry.variants[idx].second
        val u = if (p === exo) raw else castUrl(raw)
        p.setMediaItem(
            MediaItem.Builder().setUri(u).setMimeType(mime(u))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(entry.base).build()).build(),
            pos,
        )
        p.prepare()
        p.playWhenReady = true
    }

    fun position(): Long = if (active.isCurrentMediaItemLive) 0L else active.currentPosition

    fun handoff(p: Player) {
        if (p === active) return
        val pos = position()
        active.stop(); active.clearMediaItems()
        active = p
        play(p, selected, pos)
    }

    LaunchedEffect(Unit) {
        val start: Player = castPlayer?.takeIf { it.isCastSessionAvailable } ?: exo
        active = start
        play(start, 0, 0L)
    }

    DisposableEffect(Unit) {
        castPlayer?.setSessionAvailabilityListener(object : SessionAvailabilityListener {
            override fun onCastSessionAvailable() { handoff(castPlayer) }
            override fun onCastSessionUnavailable() { handoff(exo) }
        })
        onDispose {
            castPlayer?.setSessionAvailabilityListener(null)
            castPlayer?.release()
            exo.release()
        }
    }

    BackHandler(onBack = onClose)

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Retour") }
            Text(entry.base, Modifier.weight(1f), maxLines = 1, color = Color.White)
            if (cast != null) {
                AndroidView(
                    factory = { c -> MediaRouteButton(c).also { CastButtonFactory.setUpMediaRouteButton(c, it) } },
                    modifier = Modifier.size(48.dp),
                )
            }
        }
        AndroidView(
            factory = { c -> PlayerView(c).apply { player = active } },
            update = { it.player = active },
            modifier = Modifier.fillMaxWidth().weight(1f),
        )
        if (entry.variants.size > 1) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                entry.variants.forEachIndexed { i, v ->
                    FilterChip(selected == i, {
                        val pos = position()
                        selected = i
                        play(active, i, pos)
                    }, { Text(v.first) })
                }
            }
        }
    }
}
