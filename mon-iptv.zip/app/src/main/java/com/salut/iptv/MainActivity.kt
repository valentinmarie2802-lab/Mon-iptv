package com.salut.iptv

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.mediarouter.app.MediaRouteButton
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF0A0A12)
private val CardBg = Color(0xFF151522)
private val Accent = Color(0xFFFF3D6E)
private val Accent2 = Color(0xFF7C4DFF)
private val Grad = Brush.horizontalGradient(listOf(Accent, Accent2))
private val Flat = Brush.horizontalGradient(listOf(CardBg, CardBg))

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cast = try { CastContext.getSharedInstance(this) } catch (e: Exception) { null }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg, onSurface = Color.White),
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App(cast) }
            }
        }
    }
}

// ---------- réseau ----------

private fun openConn(s: String): HttpURLConnection =
    (URL(s).openConnection() as HttpURLConnection).apply {
        instanceFollowRedirects = false
        setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
        setRequestProperty("Accept", "*/*")
        setRequestProperty("Accept-Encoding", "identity")
        connectTimeout = 30000
        readTimeout = 180000
    }

private fun download(url: String, dest: File, onMb: (Long) -> Unit) {
    var u = url
    var hops = 0
    var c = openConn(u)
    while (c.responseCode in 301..308 && hops < 5) {
        u = URL(URL(u), c.getHeaderField("Location")).toString()
        c.disconnect(); c = openConn(u); hops++
    }
    if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
    var total = 0L
    var lastMb = -1L
    c.inputStream.use { i ->
        dest.outputStream().use { o ->
            val buf = ByteArray(65536)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                total += n
                val mb = total / 1048576
                if (mb != lastMb) { lastMb = mb; onMb(mb) }
            }
        }
    }
}

// ---------- petits composants ----------

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) Grad else Flat)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(
            text, color = Color.White, fontSize = 13.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
fun RoundBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(CardBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 18.sp) }
}

@Composable
fun SideRow(name: String, count: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (selected) Accent.copy(alpha = 0.28f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(name, Modifier.weight(1f), color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count", color = Color(0xFF9A9AB0), fontSize = 12.sp)
    }
}

@Composable
fun Tile(e: Entry, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val live = e.kind == Kind.LIVE
    Box(
        Modifier.fillMaxWidth().aspectRatio(if (live) 16f / 9f else 2f / 3f)
            .clip(RoundedCornerShape(12.dp)).background(CardBg).clickable(onClick = onClick),
    ) {
        AsyncImage(
            model = e.logo.ifBlank { null }, contentDescription = null,
            contentScale = if (live) ContentScale.Fit else ContentScale.Crop,
            modifier = if (live) Modifier.fillMaxSize().padding(16.dp) else Modifier.fillMaxSize(),
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .padding(start = 8.dp, top = 22.dp, end = 8.dp, bottom = 7.dp),
        ) {
            Text(e.base, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        val q = e.variants.first().first
        if (!q.startsWith("Auto")) {
            Text(
                q, Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(6.dp))
                    .background(Grad).padding(horizontal = 6.dp, vertical = 2.dp),
                color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            )
        }
        Text(
            if (fav) "★" else "☆",
            Modifier.align(Alignment.TopEnd).padding(4.dp).clip(CircleShape)
                .background(Color(0x66000000)).clickable(onClick = onFav).padding(horizontal = 8.dp, vertical = 3.dp),
            color = if (fav) Color(0xFFFFC83D) else Color.White, fontSize = 16.sp,
        )
    }
}

// ---------- écran principal ----------

@Composable
fun App(cast: CastContext?) {
    val ctx = LocalContext.current
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val prefs = remember { ctx.getSharedPreferences("iptv", 0) }
    val scope = rememberCoroutineScope()
    val cache = remember { File(ctx.filesDir, "playlist.m3u") }
    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var status by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Entry?>(null) }
    var showSettings by remember { mutableStateOf(url.isEmpty()) }

    fun load(refresh: Boolean) {
        scope.launch {
            status = "Chargement…"
            try {
                val parsed = withContext(Dispatchers.IO) {
                    var partial = false
                    if (refresh || !cache.exists()) {
                        var ok = false
                        var best: File? = null
                        var err: Exception? = null
                        for (n in 1..3) {
                            val f = File(cache.path + ".part$n")
                            try {
                                status = if (n == 1) "Téléchargement…" else "Nouvelle tentative $n/3…"
                                download(url, f) { mb -> status = "Téléchargement… $mb Mo (essai $n/3)" }
                                f.renameTo(cache); ok = true; break
                            } catch (e: java.io.IOException) {
                                err = e
                                if (f.length() > (best?.length() ?: 0L)) best = f
                            }
                        }
                        if (!ok) {
                            val bf = best
                            if (bf != null && bf.length() > 512 * 1024) { bf.renameTo(cache); partial = true }
                            else throw (err ?: Exception("Échec du téléchargement"))
                        }
                    }
                    status = "Analyse de la playlist…"
                    val text = cache.readText()
                    Pair(M3u.parse(if (partial) text.substringBeforeLast("\n") else text), partial)
                }
                entries = parsed.first
                status = when {
                    parsed.first.isEmpty() -> "Playlist vide"
                    parsed.second -> "Liste partielle : le serveur a coupé la connexion. Appuie sur ⟳ pour réessayer."
                    else -> ""
                }
            } catch (e: Exception) {
                status = "Erreur : ${e.message}"
            }
        }
    }
    LaunchedEffect(Unit) { if (url.isNotEmpty()) load(false) }

    fun toggle(k: String) {
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("favs", favs).apply()
    }

    val kinds = listOf(Kind.LIVE, Kind.FILM, Kind.SERIE)
    val base = remember(entries, tab, favs) {
        if (tab == 3) entries.filter { it.key in favs } else entries.filter { it.kind == kinds[tab] }
    }
    val counts = remember(base) { base.groupingBy { it.group }.eachCount() }
    val groups = remember(base) { base.map { it.group }.filter { it.isNotBlank() }.distinct() }
    val shown = remember(base, group, query) {
        base.filter { (group == null || it.group == group) && it.base.contains(query, true) }
    }

    val current = playing
    if (current != null) {
        PlayerScreen(current, cast) { playing = null }
        return
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "LIPTV DE VALOU", Modifier.weight(1f),
                style = TextStyle(brush = Grad, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp),
            )
            RoundBtn("⟳") { load(true) }
            RoundBtn("⚙") { showSettings = true }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("📺 Live TV", "🎬 Films", "📚 Séries", "⭐ Favoris").forEachIndexed { i, t ->
                Pill(t, tab == i) { tab = i; group = null }
            }
        }
        TextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Rechercher…") }, singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = CardBg, unfocusedContainerColor = CardBg,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        )
        if (status.isNotEmpty()) Text(status, Modifier.padding(12.dp), color = Color(0xFFFFC83D), fontSize = 13.sp)

        Row(Modifier.fillMaxSize()) {
            if (wide && groups.isNotEmpty()) {
                LazyColumn(
                    Modifier.width(220.dp).fillMaxHeight().background(CardBg).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    item { SideRow("Tous", base.size, group == null) { group = null } }
                    items(groups) { g -> SideRow(g, counts[g] ?: 0, group == g) { group = g } }
                }
            }
            Column(Modifier.weight(1f)) {
                if (!wide && groups.isNotEmpty()) {
                    LazyRow(
                        Modifier.padding(vertical = 4.dp), contentPadding = PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item { Pill("Tous", group == null) { group = null } }
                        items(groups) { g -> Pill(g, group == g) { group = g } }
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (tab == 0) 150.dp else 112.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    gridItems(shown) { e ->
                        Tile(e, e.key in favs, { toggle(e.key) }) { playing = e }
                    }
                }
            }
        }
    }

    if (showSettings) {
        var tmp by remember { mutableStateOf(url) }
        AlertDialog(
            onDismissRequest = { if (url.isNotEmpty()) showSettings = false },
            title = { Text("URL de la playlist M3U") },
            text = { OutlinedTextField(tmp, { tmp = it }) },
            confirmButton = {
                TextButton(onClick = {
                    url = tmp.trim()
                    prefs.edit().putString("url", url).apply()
                    showSettings = false
                    load(true)
                }) { Text("Charger") }
            },
        )
    }
}

// ---------- lecteur plein écran ----------

private fun Context.activity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun setFullscreen(act: Activity?, on: Boolean) {
    val w = act?.window ?: return
    val ctrl = WindowInsetsControllerCompat(w, w.decorView)
    WindowCompat.setDecorFitsSystemWindows(w, !on)
    if (on) {
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    } else {
        ctrl.show(WindowInsetsCompat.Type.systemBars())
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
    if (Build.VERSION.SDK_INT >= 28) {
        w.attributes = w.attributes.apply {
            layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
    }
}

private fun mime(u: String): String? = when {
    ".m3u8" in u -> "application/x-mpegURL"
    u.endsWith(".mp4") -> "video/mp4"
    u.endsWith(".mkv") -> "video/x-matroska"
    u.endsWith(".ts") -> "video/mp2t"
    else -> null
}

// Le Chromecast lit mal les .ts bruts : on tente le HLS pour les chaînes live.
private fun castUrl(u: String) =
    if ("/live/" in u && u.endsWith(".ts")) u.dropLast(3) + ".m3u8" else u

@Composable
fun PlayerScreen(entry: Entry, cast: CastContext?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    val castPlayer = remember { cast?.let { CastPlayer(it) } }
    var active by remember { mutableStateOf<Player>(exo) }
    var selected by remember { mutableStateOf(0) }
    var controls by remember { mutableStateOf(true) }
    var zoom by remember { mutableStateOf(false) }

    fun play(p: Player, idx: Int, pos: Long) {
        val raw = entry.variants[idx].second
        val u = if (p === exo) raw else castUrl(raw)
        p.setMediaItem(
            MediaItem.Builder().setUri(u).setMimeType(mime(u))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(entry.base).build()).build(),
            pos,
        )
        p.prepare()
        p.playWhenReady = true
    }

    fun position(): Long = if (active.isCurrentMediaItemLive) 0L else active.currentPosition

    fun handoff(p: Player) {
        if (p === active) return
        val pos = position()
        active.stop(); active.clearMediaItems()
        active = p
        play(p, selected, pos)
    }

    LaunchedEffect(Unit) {
        val start: Player = castPlayer?.takeIf { it.isCastSessionAvailable } ?: exo
        active = start
        play(start, 0, 0L)
    }

    DisposableEffect(Unit) {
        val act = ctx.activity()
        setFullscreen(act, true)
        castPlayer?.setSessionAvailabilityListener(object : SessionAvailabilityListener {
            override fun onCastSessionAvailable() { handoff(castPlayer) }
            override fun onCastSessionUnavailable() { handoff(exo) }
        })
        onDispose {
            setFullscreen(act, false)
            castPlayer?.setSessionAvailabilityListener(null)
            castPlayer?.release()
            exo.release()
        }
    }

    BackHandler(onBack = onClose)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = active
                    keepScreenOn = true
                    controllerShowTimeoutMs = 3000
                    setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
                        override fun onVisibilityChanged(visibility: Int) { controls = visibility == View.VISIBLE }
                    })
                }
            },
            update = {
                it.player = active
                it.resizeMode = if (zoom) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            },
            modifier = Modifier.fillMaxSize(),
        )
        if (controls) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(horizontal = 28.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill("←", false) { onClose() }
                Text(entry.base, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                if (entry.variants.size > 1) {
                    entry.variants.forEachIndexed { i, v ->
                        Pill(v.first, selected == i) {
                            val pos = position()
                            selected = i
                            play(active, i, pos)
                        }
                    }
                }
                Pill(if (zoom) "Ajuster" else "Zoom", false) { zoom = !zoom }
                if (cast != null) {
                    AndroidView(
                        factory = { c -> MediaRouteButton(c).also { CastButtonFactory.setUpMediaRouteButton(c, it) } },
                        modifier = Modifier.size(48.dp),
                    )
                }
            }
        }
    }
}
