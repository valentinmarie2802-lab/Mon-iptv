package com.salut.iptv

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.mediarouter.app.MediaRouteButton
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF0A0A12)
private val CardBg = Color(0xFF151522)
private val Accent = Color(0xFFFF3D6E)
private val Accent2 = Color(0xFF7C4DFF)
private val PsgBlue = Color(0xFF2A6BFF)
private val PsgRed = Color(0xFFE30A17)
private val Grad = Brush.horizontalGradient(listOf(Accent, Accent2))
private val Flat = Brush.horizontalGradient(listOf(CardBg, CardBg))

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cast = try { CastContext.getSharedInstance(this) } catch (e: Exception) { null }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg, onSurface = Color.White),
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App(cast) }
            }
        }
    }
}

// ---------- réseau ----------

internal fun openConn(s: String): HttpURLConnection =
    (URL(s).openConnection() as HttpURLConnection).apply {
        instanceFollowRedirects = false
        setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
        setRequestProperty("Accept", "*/*")
        setRequestProperty("Accept-Encoding", "identity")
        connectTimeout = 30000
        readTimeout = 180000
    }

internal fun download(url: String, dest: File, onMb: (Long) -> Unit) {
    var u = url
    var hops = 0
    var c = openConn(u)
    while (c.responseCode in 301..308 && hops < 5) {
        u = URL(URL(u), c.getHeaderField("Location")).toString()
        c.disconnect(); c = openConn(u); hops++
    }
    if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
    var total = 0L
    var lastMb = -1L
    c.inputStream.use { i ->
        dest.outputStream().use { o ->
            val buf = ByteArray(65536)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                total += n
                val mb = total / 1048576
                if (mb != lastMb) { lastMb = mb; onMb(mb) }
            }
        }
    }
}

// ---------- lecteur partagé (continue de jouer quand on revient au menu) ----------

private fun mime(u: String): String? = when {
    ".m3u8" in u -> "application/x-mpegURL"
    u.endsWith(".mp4") -> "video/mp4"
    u.endsWith(".mkv") -> "video/x-matroska"
    u.endsWith(".ts") -> "video/mp2t"
    else -> null
}

// Le Chromecast lit mal les .ts bruts : on passe par le HLS pour les chaînes en direct.
private fun castLive(u: String): String = when {
    u.endsWith(".ts") -> u.dropLast(3) + ".m3u8"
    u.substringAfterLast('/').contains('.') -> u
    else -> "$u.m3u8"
}

// Le Cast exige un type de média : on n'en laisse jamais un vide.
private fun castMime(u: String, live: Boolean): String =
    mime(u)?.takeIf { it != "video/mp2t" } ?: if (live) "application/x-mpegURL" else "video/mp4"

class Hub(private val ctx: Context, private val cast: CastContext?, private val scope: CoroutineScope) {
    val exo: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private val castPlayer: CastPlayer? = cast?.let { CastPlayer(it) }
    var active by mutableStateOf<Player>(exo)
    var entry by mutableStateOf<Entry?>(null)
    var selected by mutableStateOf(0)
    var message by mutableStateOf("")
    var failed by mutableStateOf(false)
    var playing by mutableStateOf(false)
    private var attempts = 0
    private var retryJob: Job? = null
    private var bufferJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) { onError() }
        override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        override fun onPlaybackStateChanged(state: Int) {
            bufferJob?.cancel()
            if (state == Player.STATE_READY) {
                attempts = 0; message = ""; failed = false
            } else if (state == Player.STATE_BUFFERING && entry?.kind == Kind.LIVE) {
                bufferJob = scope.launch { delay(20000); onError() }
            }
        }
    }

    init {
        exo.addListener(listener)
        castPlayer?.let { cp ->
            cp.addListener(listener)
            cp.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable() { handoff(cp) }
                override fun onCastSessionUnavailable() { handoff(exo) }
            })
        }
    }

    private fun position(): Long = if (active.isCurrentMediaItemLive) 0L else active.currentPosition

    private fun onError() {
        if (entry == null) return
        bufferJob?.cancel(); retryJob?.cancel()
        if (attempts < 3) {
            attempts++
            failed = false
            message = "Erreur de lecture, tentative de reconnexion $attempts/3"
            val pos = position()
            retryJob = scope.launch { delay(2500); play(active, selected, pos) }
        } else {
            failed = true
            message = "Oups ! Erreur de lecture. Actualise ou change de chaîne."
        }
    }

    private fun play(p: Player, idx: Int, pos: Long) {
        val e = entry ?: return
        try {
            val raw = e.variants[idx].second
            val live = e.kind == Kind.LIVE
            val isCast = p !== exo
            val u = if (isCast && live) castLive(raw) else raw
            val m = if (isCast) castMime(u, live) else mime(u)
            p.setMediaItem(
                MediaItem.Builder().setUri(u).setMimeType(m)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(e.base).build()).build(),
                pos,
            )
            p.prepare()
            p.playWhenReady = true
        } catch (ex: Exception) {
            onError()
        }
    }

    private fun handoff(p: Player) {
        if (p === active) return
        val pos = position()
        try { active.stop(); active.clearMediaItems() } catch (e: Exception) { }
        active = p
        if (entry != null) play(p, selected, pos)
    }

    fun start(e: Entry) {
        retryJob?.cancel(); bufferJob?.cancel()
        attempts = 0; failed = false; message = ""
        try { exo.stop(); castPlayer?.stop() } catch (ex: Exception) { }
        entry = e; selected = 0
        val p: Player = castPlayer?.takeIf { it.isCastSessionAvailable } ?: exo
        active = p
        play(p, 0, 0L)
    }

    fun selectQuality(i: Int) {
        val pos = position()
        selected = i; attempts = 0; failed = false; message = ""
        play(active, i, pos)
    }

    fun retryNow() {
        attempts = 0; failed = false; message = ""
        play(active, selected, position())
    }

    val casting: Boolean get() = active !== exo

    // Coupe la session Cast : la télé est libérée et la lecture reprend sur le téléphone si elle était en cours.
    fun endCast() {
        try { cast?.sessionManager?.endCurrentSession(true) } catch (e: Exception) { }
    }

    fun togglePlay() { if (active.playWhenReady) active.pause() else active.play() }

    fun stop() {
        retryJob?.cancel(); bufferJob?.cancel()
        try {
            exo.stop(); exo.clearMediaItems()
            castPlayer?.stop(); castPlayer?.clearMediaItems()
        } catch (e: Exception) { }
        entry = null; message = ""; failed = false; playing = false
        endCast()
    }

    fun release() {
        retryJob?.cancel(); bufferJob?.cancel()
        castPlayer?.setSessionAvailabilityListener(null)
        castPlayer?.release()
        exo.release()
    }
}

// ---------- petits composants ----------

@Composable
fun AnimatedTitle(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "title")
    val shift by t.animateFloat(
        initialValue = 0f, targetValue = 600f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "shift",
    )
    val brush = Brush.linearGradient(
        colors = listOf(PsgBlue, PsgRed, PsgBlue),
        start = Offset(shift, 0f), end = Offset(shift + 600f, 0f),
        tileMode = TileMode.Repeated,
    )
    Text(
        "LIPTV DE VALOU", modifier,
        style = TextStyle(brush = brush, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp),
    )
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) Grad else Flat)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(
            text, color = Color.White, fontSize = 13.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
fun RoundBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(CardBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 18.sp) }
}

@Composable
fun SideRow(name: String, count: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (selected) Accent.copy(alpha = 0.28f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(name, Modifier.weight(1f), color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count", color = Color(0xFF9A9AB0), fontSize = 12.sp)
    }
}

@Composable
fun Tile(e: Entry, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val live = e.kind == Kind.LIVE
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(320)) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    Box(
        Modifier.fillMaxWidth().aspectRatio(if (live) 16f / 9f else 2f / 3f)
            .graphicsLayer {
                val s = (0.9f + 0.1f * appear.value) * press
                alpha = appear.value; scaleX = s; scaleY = s
            }
            .clip(RoundedCornerShape(12.dp)).background(CardBg)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
    ) {
        AsyncImage(
            model = e.logo.ifBlank { null }, contentDescription = null,
            contentScale = if (live) ContentScale.Fit else ContentScale.Crop,
            modifier = if (live) Modifier.fillMaxSize().padding(16.dp) else Modifier.fillMaxSize(),
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .padding(start = 8.dp, top = 22.dp, end = 8.dp, bottom = 7.dp),
        ) {
            Text(e.base, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        val q = e.variants.first().first
        if (!q.startsWith("Auto")) {
            Text(
                q, Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(6.dp))
                    .background(Grad).padding(horizontal = 6.dp, vertical = 2.dp),
                color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            )
        }
        Text(
            if (fav) "★" else "☆",
            Modifier.align(Alignment.TopEnd).padding(4.dp).clip(CircleShape)
                .background(Color(0x66000000)).clickable(onClick = onFav).padding(horizontal = 8.dp, vertical = 3.dp),
            color = if (fav) Color(0xFFFFC83D) else Color.White, fontSize = 16.sp,
        )
    }
}

@Composable
fun MiniPlayer(hub: Hub, onOpen: () -> Unit) {
    val e = hub.entry ?: return
    Row(
        Modifier.fillMaxWidth().background(CardBg).clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        AndroidView(
            factory = { c -> PlayerView(c).apply { useController = false; player = hub.active } },
            update = { it.player = hub.active },
            modifier = Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)),
        )
        Column(Modifier.weight(1f)) {
            Text(e.base, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                when {
                    hub.message.isNotEmpty() -> hub.message
                    hub.casting -> "Diffusé sur la télé · touche pour agrandir"
                    else -> "Lecture en cours · touche pour agrandir"
                },
                color = Color(0xFF9AA0B5), fontSize = 11.sp, maxLines = 2,
            )
        }
        RoundBtn(if (hub.playing) "⏸" else "▶") { hub.togglePlay() }
        if (hub.casting) RoundBtn("⏏") { hub.endCast() }
        RoundBtn("✕") { hub.stop() }
    }
}

// ---------- écran principal ----------

@Composable
fun App(cast: CastContext?) {
    val ctx = LocalContext.current
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val prefs = remember { ctx.getSharedPreferences("iptv", 0) }
    val scope = rememberCoroutineScope()
    val hub = remember { Hub(ctx, cast, scope) }
    DisposableEffect(Unit) { onDispose { hub.release() } }

    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var status by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var full by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(url.isEmpty()) }
    var seriesOf by remember { mutableStateOf<Entry?>(null) }
    var episodes by remember { mutableStateOf<List<Entry>?>(null) }
    var sub by remember { mutableStateOf<Sub?>(null) }
    val gridState = rememberLazyGridState()

    fun load(refresh: Boolean) {
        scope.launch {
            status = "Chargement…"
            try {
                val note: String = try {
                    withContext(Dispatchers.IO) {
                        Loader.run(ctx.filesDir, url, refresh, { status = it }, { entries = it })
                    }
                } catch (e: Exception) {
                    // Certains claviers ajoutent un « s » à http : on réessaie sans.
                    if (!url.startsWith("https://", ignoreCase = true)) throw e
                    val alt = "http://" + url.substring(8)
                    val n = withContext(Dispatchers.IO) {
                        Loader.run(ctx.filesDir, alt, true, { status = it }, { entries = it })
                    }
                    url = alt
                    prefs.edit().putString("url", alt).apply()
                    n
                }
                status = note
            } catch (e: Exception) {
                status = "Erreur : ${e.message}"
            }
        }
    }
    LaunchedEffect(Unit) { if (url.isNotEmpty()) load(false) }
    LaunchedEffect(url) {
        sub = if (url.isBlank()) null else withContext(Dispatchers.IO) { Xtream.subscription(url) }
    }
    LaunchedEffect(tab, group, query) { gridState.scrollToItem(0) }

    fun toggle(k: String) {
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("favs", favs).apply()
    }

    fun playEntry(e: Entry) { hub.start(e); full = true }

    fun openEntry(e: Entry) {
        if (e.variants.first().second.startsWith("series:")) {
            seriesOf = e; episodes = null
            scope.launch {
                episodes = try {
                    withContext(Dispatchers.IO) { Loader.episodes(ctx.filesDir, url, e) }
                } catch (ex: Exception) { emptyList() }
            }
        } else playEntry(e)
    }

    val kinds = listOf(Kind.LIVE, Kind.FILM, Kind.SERIE)
    val base = remember(entries, tab, favs) {
        if (tab == 3) entries.filter { it.key in favs } else entries.filter { it.kind == kinds[tab] }
    }
    val counts = remember(base) { base.groupingBy { it.group }.eachCount() }
    val groups = remember(base) { base.map { it.group }.filter { it.isNotBlank() }.distinct() }
    val shown = remember(base, group, query) {
        base.filter { (group == null || it.group == group) && it.base.contains(query, true) }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AnimatedTitle(Modifier.weight(1f))
                RoundBtn("⟳") { load(true) }
                if (cast != null) {
                    AndroidView(
                        factory = { c -> MediaRouteButton(c).also { CastButtonFactory.setUpMediaRouteButton(c, it) } },
                        modifier = Modifier.size(40.dp),
                    )
                }
                RoundBtn("⚙") { showSettings = true }
            }
            AnimatedVisibility(visible = sub != null, enter = fadeIn(tween(500)), exit = fadeOut()) {
                val s = sub
                Text(
                    s?.text ?: "", Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp),
                    color = if (s?.warn == true) Color(0xFFFF6B6B) else Color(0xFF9AA0B5), fontSize = 12.sp,
                )
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("📺 Live TV", "🎬 Films", "📚 Séries", "⭐ Favoris").forEachIndexed { i, t ->
                    Pill(t, tab == i) { tab = i; group = null }
                }
            }
            TextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Rechercher…") }, singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = CardBg, unfocusedContainerColor = CardBg,
                ),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            )
            if (status.isNotEmpty()) Text(status, Modifier.padding(12.dp), color = Color(0xFFFFC83D), fontSize = 13.sp)

            Row(Modifier.weight(1f)) {
                if (wide && groups.isNotEmpty()) {
                    LazyColumn(
                        Modifier.width(220.dp).fillMaxHeight().background(CardBg).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        item { SideRow("Tous", base.size, group == null) { group = null } }
                        items(groups) { g -> SideRow(g, counts[g] ?: 0, group == g) { group = g } }
                    }
                }
                Column(Modifier.weight(1f)) {
                    if (!wide && groups.isNotEmpty()) {
                        LazyRow(
                            Modifier.padding(vertical = 4.dp), contentPadding = PaddingValues(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            item { Pill("Tous", group == null) { group = null } }
                            items(groups) { g -> Pill(g, group == g) { group = g } }
                        }
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(if (tab == 0) 150.dp else 112.dp),
                        state = gridState,
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        gridItems(shown, key = { "${it.key}|${it.group}" }) { e ->
                            Tile(e, e.key in favs, { toggle(e.key) }) { openEntry(e) }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !full && hub.entry != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) { MiniPlayer(hub) { full = true } }
        }

        AnimatedVisibility(
            visible = full && hub.entry != null,
            enter = fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.92f),
            exit = fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.92f),
        ) { PlayerScreen(hub) { full = false } }
    }

    val so = seriesOf
    if (so != null) {
        AlertDialog(
            onDismissRequest = { seriesOf = null },
            title = { Text(so.base, maxLines = 2) },
            text = {
                val eps = episodes
                when {
                    eps == null -> Text("Chargement des épisodes…")
                    eps.isEmpty() -> Text("Aucun épisode trouvé.")
                    else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(eps) { ep ->
                            Text(
                                ep.base,
                                Modifier.fillMaxWidth().clickable { seriesOf = null; playEntry(ep) }.padding(vertical = 12.dp),
                                fontSize = 14.sp,
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { seriesOf = null }) { Text("Fermer") } },
        )
    }

    if (showSettings) {
        var tmp by remember { mutableStateOf(url) }
        AlertDialog(
            onDismissRequest = { if (url.isNotEmpty()) showSettings = false },
            title = { Text("URL de la playlist M3U") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Colle ton lien ici. Si ton clavier ajoute un « s » à http, l'application le corrige toute seule.", fontSize = 12.sp)
                    OutlinedTextField(tmp, { tmp = it })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    url = tmp.trim().replace(Regex("\\s"), "").replace("&amp;", "&")
                    prefs.edit().putString("url", url).apply()
                    showSettings = false
                    load(true)
                }) { Text("Charger") }
            },
        )
    }
}

// ---------- lecteur plein écran ----------

private fun Context.activity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun setFullscreen(act: Activity?, on: Boolean) {
    val w = act?.window ?: return
    val ctrl = WindowInsetsControllerCompat(w, w.decorView)
    WindowCompat.setDecorFitsSystemWindows(w, !on)
    if (on) {
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    } else {
        ctrl.show(WindowInsetsCompat.Type.systemBars())
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
    if (Build.VERSION.SDK_INT >= 28) {
        w.attributes = w.attributes.apply {
            layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
    }
}

@Composable
fun PlayerScreen(hub: Hub, onMinimize: () -> Unit) {
    val entry = hub.entry ?: return
    val ctx = LocalContext.current
    var controls by remember { mutableStateOf(true) }
    var zoom by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val act = ctx.activity()
        setFullscreen(act, true)
        onDispose { setFullscreen(act, false) }
    }
    BackHandler(onBack = onMinimize)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = hub.active
                    keepScreenOn = true
                    controllerShowTimeoutMs = 3000
                    setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
                        override fun onVisibilityChanged(visibility: Int) { controls = visibility == View.VISIBLE }
                    })
                }
            },
            update = {
                it.player = hub.active
                it.resizeMode = if (zoom) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            },
            modifier = Modifier.fillMaxSize(),
        )

        if (hub.message.isNotEmpty()) {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC000000)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (!hub.failed) CircularProgressIndicator(color = Accent, modifier = Modifier.size(28.dp))
                Text(hub.message, color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                if (hub.failed) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Réessayer", true) { hub.retryNow() }
                        Pill("Retour", false) { onMinimize() }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = controls,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(horizontal = 28.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill("←", false) { onMinimize() }
                Text(entry.base, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                if (entry.variants.size > 1) {
                    entry.variants.forEachIndexed { i, v ->
                        Pill(v.first, hub.selected == i) { hub.selectQuality(i) }
                    }
                }
                Pill(if (zoom) "Ajuster" else "Zoom", false) { zoom = !zoom }
                if (hub.casting) Pill("⏏ Stop Cast", false) { hub.endCast() }
                Pill("Arrêter", false) { hub.stop(); onMinimize() }
                AndroidView(
                    factory = { c -> MediaRouteButton(c).also { CastButtonFactory.setUpMediaRouteButton(c, it) } },
                    modifier = Modifier.size(48.dp),
                )
            }
        }
    }
}
