package com.salut.iptv

import java.io.File

object Loader {
    fun run(
        dir: File, url: String, refresh: Boolean,
        setStatus: (String) -> Unit, setEntries: (List<Entry>) -> Unit,
    ): String {
        val xc = Xtream.fromUrl(url)
        var fallbackNote = ""
        try {
            val note = m3u(dir, url, refresh, setStatus, setEntries)
            if (note.isEmpty() || xc == null) return note
            fallbackNote = note
        } catch (e: Exception) {
            if (xc == null) throw e
        }
        setStatus("Chargement par l'API…")
        return try {
            xtream(dir, xc, refresh, setStatus, setEntries)
        } catch (e: Exception) {
            if (fallbackNote.isNotEmpty()) fallbackNote else throw e
        }
    }

    // Retourne true si le fichier est partiel (connexion coupée).
    private fun fetchTo(u: String, dest: File, onMb: (Long) -> Unit): Boolean {
        var best: File? = null
        var err: Exception? = null
        for (n in 1..3) {
            val f = File(dest.path + ".t$n")
            try {
                download(u, f, onMb)
                f.renameTo(dest)
                return false
            } catch (e: java.io.IOException) {
                if (e.message?.startsWith("HTTP 4") == true) throw e
                err = e
                if (f.length() > (best?.length() ?: 0L)) best = f
            }
        }
        val b = best
        if (b != null && b.length() > 2048) { b.renameTo(dest); return true }
        throw (err ?: Exception("Échec du téléchargement"))
    }

    private fun xtream(
        dir: File, xc: XCfg, refresh: Boolean,
        setStatus: (String) -> Unit, setEntries: (List<Entry>) -> Unit,
    ): String {
        val sections = listOf(
            Triple(Kind.LIVE, "get_live_categories", "get_live_streams"),
            Triple(Kind.FILM, "get_vod_categories", "get_vod_streams"),
            Triple(Kind.SERIE, "get_series_categories", "get_series"),
        )
        val labels = mapOf(Kind.LIVE to "chaînes", Kind.FILM to "films", Kind.SERIE to "séries")
        val all = ArrayList<Entry>()
        val notes = ArrayList<String>()
        for ((kind, catA, dataA) in sections) {
            val label = labels[kind] ?: ""
            val n = kind.name.lowercase()
            val catF = File(dir, "x_${n}_cat.json")
            val dataF = File(dir, "x_$n.json")
            try {
                if (refresh || !dataF.exists()) {
                    try { fetchTo(Xtream.api(xc, catA), catF) { } } catch (e: Exception) { }
                    val partial = fetchTo(Xtream.api(xc, dataA), dataF) { mb ->
                        setStatus("Téléchargement des $label… $mb Mo")
                    }
                    if (partial) notes += "$label : téléchargement incomplet (connexion coupée), appuie sur ⟳"
                }
                setStatus("Analyse des $label…")
                all += M3u.group(Xtream.items(xc, kind, catF, dataF))
                setEntries(all.toList())
            } catch (e: Exception) {
                notes += "$label : ${e.message}"
            }
        }
        if (all.isEmpty()) throw Exception(notes.joinToString(" · ").ifBlank { "Aucun contenu" })
        return notes.joinToString(" · ")
    }

    private fun m3u(
        dir: File, url: String, refresh: Boolean,
        setStatus: (String) -> Unit, setEntries: (List<Entry>) -> Unit,
    ): String {
        val cache = File(dir, "playlist.m3u")
        var partial = false
        if (refresh || !cache.exists()) {
            partial = fetchTo(url, cache) { mb -> setStatus("Téléchargement… $mb Mo") }
        }
        setStatus("Analyse de la playlist…")
        val text = cache.readText()
        val list = M3u.parse(if (partial) text.substringBeforeLast("\n") else text)
        setEntries(list)
        return when {
            list.isEmpty() -> "Playlist vide"
            partial -> "Liste partielle : le serveur a coupé la connexion. Appuie sur ⟳ pour réessayer."
            else -> ""
        }
    }

    fun episodes(dir: File, url: String, e: Entry): List<Entry> {
        val xc = Xtream.fromUrl(url) ?: return emptyList()
        val id = e.variants.first().second.removePrefix("series:")
        val f = File(dir, "x_series_info.json")
        fetchTo(Xtream.api(xc, "get_series_info", "&series_id=$id"), f) { }
        return Xtream.episodes(xc, e, f)
    }
}
