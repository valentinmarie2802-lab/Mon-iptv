package com.salut.iptv

enum class Kind { LIVE, FILM, SERIE }

data class Item(val name: String, val url: String, val logo: String, val group: String, val kind: Kind)

data class Entry(
    val base: String,
    val logo: String,
    val group: String,
    val kind: Kind,
    val variants: List<Pair<String, String>>, // (qualité, url)
) {
    val key: String get() = "$kind:${base.lowercase()}"
}

object M3u {
    private val q = Regex("""\b(FULL ?HD|FHD|UHD|4K|HD|SD)\b""", RegexOption.IGNORE_CASE)

    private fun attr(l: String, k: String) =
        Regex("""$k="([^"]*)"""").find(l)?.groupValues?.get(1) ?: ""

    private fun base(n: String): String {
        val c = q.replace(n, " ").replace(Regex("""[\[\]()|]+"""), " ")
            .replace(Regex("""\s+"""), " ").trim()
        return c.ifBlank { n }
    }

    private fun label(n: String): String {
        val m = q.find(n)?.value?.uppercase()?.replace(" ", "") ?: return "Auto"
        return when (m) { "FULLHD", "FHD" -> "FHD"; "UHD", "4K" -> "4K"; else -> m }
    }

    private fun rank(l: String) = when (l) { "4K" -> 0; "FHD" -> 1; "HD" -> 2; "Auto" -> 3; else -> 4 }

    private fun dedupe(l: List<Pair<String, String>>): List<Pair<String, String>> {
        val total = l.groupingBy { it.first }.eachCount()
        val seen = HashMap<String, Int>()
        return l.map { (k, u) ->
            if ((total[k] ?: 0) > 1) { val n = (seen[k] ?: 0) + 1; seen[k] = n; "$k $n" to u } else k to u
        }
    }

    private fun kind(u: String, g: String): Kind {
        val gl = g.lowercase()
        return when {
            "/movie/" in u -> Kind.FILM
            "/series/" in u -> Kind.SERIE
            "serie" in gl || "série" in gl -> Kind.SERIE
            "film" in gl || "movie" in gl || "vod" in gl || "cine" in gl || "ciné" in gl -> Kind.FILM
            else -> Kind.LIVE
        }
    }

    fun parse(text: String): List<Entry> {
        val items = ArrayList<Item>()
        var name = ""; var logo = ""; var group = ""
        for (raw in text.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXTINF")) {
                name = l.substringAfterLast(",").trim()
                logo = attr(l, "tvg-logo")
                group = attr(l, "group-title")
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                items += Item(name, l, logo, group, kind(l, group))
                name = ""; logo = ""; group = ""
            }
        }
        return items.groupBy { Triple(base(it.name).lowercase(), it.kind, it.group) }.map { (_, v) ->
            Entry(
                base(v[0].name), v[0].logo, v[0].group, v[0].kind,
                dedupe(v.map { label(it.name) to it.url }.sortedBy { rank(it.first) }),
            )
        }
    }
}
